﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// ColorImageAlpha1.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_ColorImageAlpha1TYPE        130
#define IDD_CONSTANT1                   314
#define IDD_CONSTANT2                   315
#define IDD_CONSTANT3                   316
#define IDD_CONSTANT4                   317
#define IDCANCEL                        1001
#define IDC_EDIT_CONSTANT1              1002
#define IDC_EDIT_CONSTANT2              1003
#define IDC_EDIT_CONSTANT4              1004
#define ID_32771                        32771
#define ID                              32772
#define IDM_EQUAL_IMAGE                 32773
#define ID_32774                        32774
#define IDM_GRAY_SCALE                  32775
#define ID_32776                        32776
#define IDM_CHANGE_SATUR                32777
#define ID_32778                        32778
#define IDM_PICK_ORANGE                 32779
#define ID_32780                        32780
#define IDM_EMBOSS                      32781
#define ID_32782                        32782
#define IDM_EMBOSS_HSI                  32783
#define ID_32784                        32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_32787                        32787
#define ID_32788                        32788
#define ID_32789                        32789
#define ID_32790                        32790
#define ID_32791                        32791
#define ID_32792                        32792
#define ID_32793                        32793
#define ID_32794                        32794
#define ID_32795                        32795
#define ID_32796                        32796
#define ID_32797                        32797
#define ID_32798                        32798
#define ID_32799                        32799
#define ID_32800                        32800
#define ID_32801                        32801
#define ID_32802                        32802
#define ID_32803                        32803
#define ID_32804                        32804
#define ID_32805                        32805
#define ID_32806                        32806
#define ID_32807                        32807
#define ID_32808                        32808
#define ID_32809                        32809
#define ID_32810                        32810
#define ID_32811                        32811
#define ID_32812                        32812
#define ID_32813                        32813
#define ID_32814                        32814
#define ID_32815                        32815
#define IDM_ADD_IMAGE                   32816
#define IDM_DARK_IMAGE                  32817
#define IDM_REVERSE_IMAGE               32818
#define IDM_BW_IMAGE                    32819
#define IDM_GAMMA_IMAGE                 32820
#define IDM_PARABOLA_CAP                32821
#define IDM_PARABOLA_CUP                32822
#define IDM_AND_IMAGE                   32823
#define IDM_OR_IMAGE                    32824
#define IDM_XOR_IMAGE                   32825
#define IDM_BLUR_IMAGE                  32826
#define IDM_SHARP_IMAGE                 32827
#define IDM_EDGE_IMAGE                  32828
#define IDM_ZOOM_IN1                    32829
#define IDM_ZOOM_IN2                    32830
#define IDM_ZOOM_IN3                    32831
#define IDM_ZOOM_OUT                    32832
#define IDM_MOVE_IMAGE                  32833
#define IDM_ROTATE1                     32834
#define IDM_ROTATE2                     32835
#define IDM_ROTATE3                     32836
#define IDM_REVERSE_IMAGE1              32837
#define IDM_REVERSE_IMAGE2              32838
#define IDM_HISTO_STRETCH               32839
#define IDM_END_IN                      32840
#define IDM_HISTO_EQUAL                 32841

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        316
#define _APS_NEXT_COMMAND_VALUE         32842
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
